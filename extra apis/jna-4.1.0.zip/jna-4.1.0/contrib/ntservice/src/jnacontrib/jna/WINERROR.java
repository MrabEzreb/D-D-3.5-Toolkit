/*
 * WINERROR.java
 *
 * Created on 7. August 2007, 08:09
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package jnacontrib.jna;


/**
 *
 * @author TB
 */
public interface WINERROR {
  public final static int ERROR_SUCCESS = 0;
  public final static int NO_ERROR = 0;
  public final static int ERROR_FILE_NOT_FOUND = 2;
  public final static int ERROR_MORE_DATA = 234;
}
